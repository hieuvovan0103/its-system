package com.example.content_management_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContentManagementServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
